import React from 'react';
import IpInfo from './Components/IpInfo';
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";

function App() {
  return (
    <IpInfo />
  );
}

export default App;
